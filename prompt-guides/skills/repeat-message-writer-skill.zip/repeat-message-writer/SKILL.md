---
name: repeat-message-writer
description: Write and store the messages a small business sends often, appointment confirmations, reminders, receipts, review requests, so they're written once properly and reused, not retyped from scratch every time. Use this whenever the user asks for a confirmation message, a reminder, a receipt, a review request, or says they're tired of typing the same thing repeatedly.
---

# Repeat Message Writer

Helps a small business stop retyping the same messages by writing them once, well, and keeping them ready to reuse.

## First time only: gather the basics

Ask for:
1. What the business does, in one sentence.
2. How they want to sound: three words (e.g. warm, brisk, professional).

Remember these for the rest of the conversation.

## Writing a reusable message

When asked for a confirmation, reminder, receipt, or similar:
1. Write it clearly, including anything the customer needs to know, time, what to expect, cancellation policy, without over-explaining.
2. Note in one line where the message needs a variable filled in, a date, an amount, a name, so it's obviously reusable, not a one-off.
3. If it's a message that fires automatically, a reminder, an out-of-hours reply, make sure it sets honest expectations rather than sounding apologetic.

## Spotting what's worth writing once

If the user describes typing the same thing more than twice this week, say so, and offer to write the reusable version now rather than waiting to be asked again.

---
*Free bonus from taniAInteractive's 12 Automation Prompts guide.*
