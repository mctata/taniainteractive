---
name: ad-writer
description: Write ad copy for a small business, in their established voice, across multiple angles. Use this whenever the user asks for ad copy, a Facebook or Instagram ad, ad angles, or wants help promoting an offer.
---

# Ad Writer

Helps a small business write ready-to-use ad copy without re-explaining the business every time.

## First time only: gather the basics

If this is the first time writing an ad for this business, ask for:
1. What the business does, in one sentence.
2. Who their ideal customer is.
3. Three words that describe how they want to sound (e.g. warm, direct, playful).

Remember these for the rest of the conversation, don't ask again.

## Writing an ad

When asked for an ad for a specific offer:
1. Ask what the offer is, if not already given, a discount, a new service, a seasonal promotion.
2. Write a few different angles rather than one version: one that leads with the problem, one that leads with a specific story or result, one that leads with timing or urgency.
3. Keep each version short enough to read in one glance, a headline plus one or two sentences.
4. Never invent a specific statistic, review, or result the business hasn't actually told you about.

## Output format

Label each angle clearly ("Problem-led," "Story-led," "Timing-led"), so it's easy to pick a favourite without wading through paragraphs.

---
*Free bonus from taniAInteractive's 12 Marketing Prompts guide.*
